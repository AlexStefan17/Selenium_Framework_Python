class HomePageData:
    test_HomePage_data = [
        {"firstname": "Rahul", "lastname": "shetty", "gender": "Male"},
        {"firstname": "Alex", "lastname": "Stefan", "gender": "Male"}
    ]
