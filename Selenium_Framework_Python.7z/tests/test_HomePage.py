import pytest
from selenium.webdriver.support.select import Select
from selenium import webdriver

from pageObjects.HomePage import HomePage
from utilities.BaseClass import BaseClass
import pytest


class TestHomePage(BaseClass):

    def test_formSubmission(self, getData):
        homepage = HomePage(self.driver)
        homepage.getName().send_keys(getData["name"])
        homepage.getEmail().send_keys(getData["email"])
        homepage.getCheckBox().click()
        self.selectOptionByTest(homepage.getGender(), getData["gender"])

        homepage.submitForm().click()

        alertText = homepage.getSuccessMessage().text

        assert ("Success" in alertText)

    @pytest.fixture(params=[
        {"name": "Rahul", "email": "shetty", "gender": "Male"},
        {"name": "Alex", "email": "Stefan", "gender": "Male"}
    ])
    def getData(self, request):
        return request.param

